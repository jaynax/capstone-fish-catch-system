@extends('layouts.users.app')

@section('content')
<div class="container mt-5">
    <div class="card p-4 shadow">
        <h2 class="mb-4 text-center fw-bold">Login History</h2>
        <p>This is a placeholder for the login history page. You can implement the actual login history table here.</p>
    </div>
</div>
@endsection 